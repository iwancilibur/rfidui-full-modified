<?php 
   require "koneksidb.php";	
	$data = query("SELECT * FROM tb_monitoring")[0];
	error_reporting(0);
    $datax = query("SELECT * FROM tb_monitoring,tb_daftarrfid WHERE tb_daftarrfid.rfid=tb_monitoring.rfid ")[0];
	
 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<title>	</title>
 </head>
 <body>

   <div class="row">
                           
		<div class="col-xl-4 col-lg-3 col-md-6 col-sm-12 col-12">
			<div class="card border-3 border-top border-top-primary">
				<div class="card-body" align="center">
					<ul class="list-group">
					<h1> Deteksi RFID</h1>
					  <h1><li class="list-group-item active"><?=$data["rfid"];?></li></h1>
					  <li class="list-group-item">
						<table class="table">
							<p><span class="icon-circle-small icon-box-xs text-success bg-success-light"> <i class="fa fa-fw fa-arrow-up"></i></span> Update :<span class="ml-1"><?=$datax["tanggal"];?></span></p>
							<tr>
							  <th><img src="assets/images/user.png" height="100" width="100" > </th>
							  <th scope="row"><h1><?=$datax["nama"];?></h1></th>
							  <td></td>
							</tr>
							<tr>
							  <th><img src="assets/images/alamat.png" height="100" width="100" > </th>
							  <th scope="row"><h1><?=$datax["alamat"];?></h1></th>
							  <td></td>
							</tr>
							<tr>
							  <th><img src="assets/images/telepon.png" height="100" width="100" > </th>
							  <th scope="row"><h1><?=$datax["telepon"];?></h1></th>
							  <td></td>
							</tr>
							<tr>
							  <th><img src="assets/images/saldo.png" height="100" width="100" > </th>
							  <th scope="row"><h1><?=$datax["saldo"];?></h1></th>
							  <td></td>
							  <td></td>
							</tr>
							<tr>
							  <th><img src="assets/images/tol.png" height="100" width="100" > </th>
							  <th scope="row"><h1><?=$data["namatol"];?></h1></th>
							  <td></td>
							  <td></td>
							</tr>
						</table>
					  </li>
					</ul>
				</div>
			</div>
		</div>
		
		<div class="col-xl-8 col-lg-3 col-md-6 col-sm-12 col-12">
			<div class="card border-3 border-top border-top-primary">
				<div class="card-body" align="center">
					<h1>Realtime Data</h1>
					<div class="table-responsive">
                                    <table id="example" class="table table-striped table-bordered second" style="width:100%">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Tanggal</th>
                                                <th>Rfid</th>
												<th>Nama</th>
												<th>Alamat</th>
												<th>Telepon</th>
												<th>Saldo Awal</th>
												<th>Bayar</th>
												<th>Saldo Ahir</th>
												<th>Masuk Tol</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            
                                                $datatampil = mysqli_query($koneksi, "SELECT * from tb_simpan,tb_daftarrfid WHERE tb_simpan.rfid = tb_daftarrfid.rfid   ORDER BY no DESC LIMIT 12");
												$no=1;
                                                if (is_array($datatampil) || is_object($datatampil)){
                                                    foreach ($datatampil as $row){
                                                        echo "<tr class= bg-white >
                                                                <td>$no</td>
                                                                <td>".$row['tanggal']."</td>
                                                                <td>".$row['rfid']."</td>
																<td>".$row['nama']."</td>
																<td>".$row['alamat']."</td>
																<td>".$row['telepon']."</td>
																<td>".$row['saldoawal']."</td>
																<td>".$row['bayar']."</td>
																<td>".$row['saldoahir']."</td>	
																<td>".$row['namatol']."</td>																	
                                                            </tr>";
                                                        $no++;
                                                    }
                                                }

                                                $koneksi->close();
                                            ?>
                                        </tbody>
                                    </table>

                                   

                                </div>
					
				</div>
			</div>
		</div>
                         
    </div>	

 </body>
 </html>