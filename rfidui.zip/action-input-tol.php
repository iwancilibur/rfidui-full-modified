<?php

    require "koneksidb.php";
	date_default_timezone_set('Asia/Jakarta');
    $tgl=date("Y-m-d G:i:s");
	
    if ($_POST['Submit'] == "Submit") {
        $getnamatol    = $_POST['namatol'];
		$getbayar      = $_POST['bayar'];
		
		//Log data saldo
		$input = "INSERT INTO tb_tol (namatol, bayar) VALUES 
		('" . $getnamatol . "','" . $getbayar . "')";
        $koneksi->query($input);
		
        header("Location: inputtol.php?pesan=berhasil");
    }

?>