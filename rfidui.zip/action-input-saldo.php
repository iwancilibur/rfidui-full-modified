<?php

    require "koneksidb.php";
	date_default_timezone_set('Asia/Jakarta');
    $tgl=date("Y-m-d G:i:s");
	
    if ($_POST['Submit'] == "Submit") {
        $getrfid            = $_POST['rfid'];
		$inputsaldo      = $_POST['inputsaldo'];
		
		//AMBIL DATA SALDO AWAL
   	  	$getsaldo = query("SELECT * FROM tb_daftarrfid WHERE rfid='$getrfid'" )[0];
		$nama = $getsaldo['nama'];
		$saldoawal = $getsaldo['saldo'];
		$updatesaldo=$saldoawal+$inputsaldo; //Menambah Saldo
		
        //Masukan data ke Table
        $sqlupdate = "UPDATE tb_daftarrfid SET saldo ='$updatesaldo' WHERE rfid='$getrfid'";
		$koneksi->query($sqlupdate);
		
		//Log data saldo
		$input = "INSERT INTO tb_logsaldo (tanggal,rfid, nama, saldoawal, tambahsaldo, saldoahir) VALUES 
		('" . $tgl . "','" . $getrfid . "', '" . $nama . "', '" . $saldoawal . "', '" . $inputsaldo . "', '" . $updatesaldo . "')";
        $koneksi->query($input);
		
        header("Location: saldo-tables.php?pesan=berhasil");
    }

?>