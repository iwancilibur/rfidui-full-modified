<?php 
   error_reporting(0);
   require "koneksidb.php";

   $ambilrfid	 = $_GET["rfid"];
   $ambiltol	 = $_GET["namatol"];
   
   date_default_timezone_set('Asia/Jakarta');
   $tgl=date("Y-m-d G:i:s");
  
		//AMBIL NAMA TOL RUBAH KE BAYAR
		$gettol = query("SELECT * FROM tb_tol WHERE namatol='$ambiltol'" )[0];
		$ambilbayar = $gettol['bayar'];
		//echo $ambilbayar;
		
		//AMBIL DATA SALDO DAN RFID DARI DATA YANG SUDAH ADA
   	  	$getsaldo = query("SELECT * FROM tb_daftarrfid WHERE rfid='$ambilrfid'" )[0];
		$saldoawal = $getsaldo['saldo'];
		$cekrfid   = $getsaldo['rfid'];
	
		if($saldoawal<$ambilbayar){
			$ceksaldo="kurang";
		}else{
			$ceksaldo="cukup";
		}
		
		//UPDATE DATA REALTIME PADA TABEL tb_monitoring
		$sql      = "UPDATE tb_monitoring SET rfid='$ambilrfid', namatol='$ambiltol', ceksaldo= '$ceksaldo'";
		$koneksi->query($sql);
		
		//KIRIM DATA PALSU KE ARDUINO JIKA REQUEST RFID TIDAK TERDAFTAR
		//=================================================================//
		if($cekrfid==null){
			//MEMBUAT DATA UNTUK DIJADIKAN JSON DAN DIKIRIM KE ARDUIO
			$datadumy=array('id'=>'0','rfid'=>$ambilrfid,'nama'=>'Tidak Terdaftar','alamat'=>'Tidak Terdaftar','telepon'=>'Tidak Terdaftar','saldo'=>'Tidak Terdaftar','tanggal'=>$tgl,'namatol'=>$ambiltol,'ceksaldo'=>$ceksaldo);
			$result = json_encode($datadumy); //MENJADIKAN JSON DATA
			echo $result;
		}
		
		//KIRIM DATA KE ARDUINO JIKA REQUEST RFID TERDAFTAR DAN SALDO CUKUP
		//=================================================================//
		if($ceksaldo=="cukup" and $cekrfid!=null){
			//PERINTAH PENGURANGAN SALDO
			$updatesaldo=$saldoawal-$ambilbayar; 
			
			//UPDATE DATA REALTIME PADA TABEL tb_daftarrfid  
			$sqlupdate = "UPDATE tb_daftarrfid SET saldo ='$updatesaldo' WHERE rfid='$ambilrfid'";
			$koneksi->query($sqlupdate);
			
			//UPDATE DATA REALTIME PADA TABEL tb_monitoring
			$sql      = "UPDATE tb_monitoring SET tanggal	= '$tgl', rfid	= '$ambilrfid', namatol	= '$ambiltol'";
			$koneksi->query($sql);
				
			//INSERT DATA REALTIME PADA TABEL tb_save  	
			$sqlsave = "INSERT INTO tb_simpan (tanggal, rfid,saldoawal,bayar,saldoahir,namatol) VALUES ('" . $tgl . "', '" . $ambilrfid . "', '" . $saldoawal . "', '" . $ambilbayar . "', '" . $updatesaldo . "', '" . $ambiltol . "')";
			$koneksi->query($sqlsave);
					
			//MENGABIL DATA UNTUK DIJADIKAN JSON DAN DIKIRIM KE ARDUIO
			$response = query("SELECT * FROM tb_daftarrfid,tb_monitoring WHERE tb_daftarrfid.rfid='$ambilrfid'" )[0];
			$result = json_encode($response);//MENJADIKAN JSON DATA
			echo $result;
			}
			
			//KIRIM DATA KE ARDUINO JIKA REQUEST RFID TERDAFTAR DAN SALDO TIDAK CUKUP
			//=================================================================//
			else if ($ceksaldo=="kurang" and $cekrfid!=null){
			//MENGABIL DATA UNTUK DIJADIKAN JSON DAN DIKIRIM KE ARDUIO
			$response = query("SELECT * FROM tb_daftarrfid,tb_monitoring WHERE tb_daftarrfid.rfid='$ambilrfid'" )[0];
			$result = json_encode($response); //MENJADIKAN JSON DATA
			echo $result;
			//echo $ceksaldo;
			//echo $cekrfid;
		}
		
 ?>